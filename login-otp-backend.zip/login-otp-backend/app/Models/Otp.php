<?php

namespace App\Models;

class Otp
{
    public static function generate()
    {
        return rand(100000, 999999);
    }

    public static function isValid($inputOtp)
    {
        return session('otp') == $inputOtp;
    }
}
