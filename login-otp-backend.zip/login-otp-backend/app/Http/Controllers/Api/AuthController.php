<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\Otp;

class AuthController extends Controller
{
    public function sendOtp(Request $request)
    {
        $request->validate([
            'email' => 'required|email'
        ]);

        $otp = Otp::generate();

        session([
            'otp' => $otp,
            'email' => $request->email,
            'otp_expires_at' => now()->addMinutes(2)
        ]);

        return response()->json([
            'message' => 'OTP generado correctamente',
            'otp' => $otp // Solo para pruebas
        ]);
    }

    public function verifyOtp(Request $request)
    {
        $request->validate([
            'otp' => 'required|numeric'
        ]);

        if (now()->gt(session('otp_expires_at'))) {
            return response()->json([
                'message' => 'OTP expirado'
            ], 401);
        }

        if (Otp::isValid($request->otp)) {

            session()->forget('otp');

            return response()->json([
                'message' => 'Login exitoso'
            ]);
        }

        return response()->json([
            'message' => 'OTP incorrecto'
        ], 401);
    }
}
