<?php

use Illuminate\Support\Facades\Route;


Route::get('/', function () {
    return view('welcome');
});


Route::get('/', [OtpController::class, 'showEmailForm']);
Route::post('/send-otp', [OtpController::class, 'sendOtp'])->name('send.otp');
